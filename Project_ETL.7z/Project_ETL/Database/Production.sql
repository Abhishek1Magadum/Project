

Create database if not exists Production;
use Production;
CREATE TABLE load1 (
    Employee_ID INT AUTO_INCREMENT PRIMARY KEY,
    First_Name VARCHAR(50),
    Email VARCHAR(100)
);

use Production;
CREATE TABLE load2 (
Employee_ID  INT AUTO_INCREMENT PRIMARY KEY,
 Gender CHAR(1),
 Date_of_Birth DATE
);

use Production;
select * from load2;

use Production;
create table lastproduct
(
 Employee_ID INT AUTO_INCREMENT PRIMARY KEY,
    First_Name VARCHAR(50),
    Email VARCHAR(100),
    Gender CHAR(1),
 Date_of_Birth DATE
    
);



