CREATE DATABASE IF NOT EXISTs emp_load2;

use emp_load2;
CREATE TABLE Personal_Details (
Employee_ID  INT AUTO_INCREMENT PRIMARY KEY,
 Gender CHAR(1),
 Date_of_Birth DATE
);

select * from Personal_Details;