

CREATE DATABASE IF NOT EXISTS Eployee_Load1;
CREATE TABLE Empl_Load1 (
    Employee_ID INT AUTO_INCREMENT PRIMARY KEY,
    First_Name VARCHAR(50),
    Email VARCHAR(100)
);

use Eployee_Load1;
truncate table Empl_Load1;

  use Eployee_Load1;
  select * from Empl_Load1;
  
  