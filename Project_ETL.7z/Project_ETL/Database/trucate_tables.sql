

use EMP_DTLS;
truncate table Employee_Details;

use stagged_employee;
truncate table Employee_Details;

use stagged_employee;
truncate table test_stgged;

use Eployee_Load1;
truncate table Empl_Load1;

use emp_load2;
truncate TABLE Personal_Details;

use Production;
truncate table load1;
truncate table load2;

drop table test_stgged;

use stagged_employee;
truncate table test_stgged;
DELETE FROM Employee_Details WHERE Employee_ID IS NULL;