create database EMP_DTLS;
use EMP_DTLS;
CREATE TABLE Employee_Details (
    Employee_ID INT PRIMARY KEY,
    First_Name VARCHAR(50),
    Last_Name VARCHAR(50),
    Gender CHAR(1),
    Date_of_Birth DATE,
    Contact_Number VARCHAR(15),
    Email VARCHAR(100),
    Department VARCHAR(50),
    Designation VARCHAR(50),
    Date_of_Joining DATE,
    Salary DECIMAL(10,2),
    Address VARCHAR(255),
    Status VARCHAR(20)
);
select * from Employee_Details;

INSERT INTO Employee_Details (
    Employee_ID,
    First_Name,
    Last_Name,
    Gender,
    Date_of_Birth,
    Contact_Number,
    Email,
    Department,
    Designation,
    Date_of_Joining,
    Salary,
    Address,
    Status
) VALUES
(1, 'Amit', 'Sharma', 'M', '1990-05-12', '9876543210', 'amit.sharma@example.com', 'IT', 'Software Engineer', '2020-01-15', 60000.00, '123 MG Road, Pune', 'Active'),
(2, 'Sneha', 'Patil', 'F', '1992-08-22', '9123456789', 'sneha.patil@example.com', 'HR', 'HR Manager', '2019-03-10', 55000.00, '45 FC Road, Pune', 'Active'),
(3, 'Rahul', 'Desai', 'M', '1988-02-28', '9988776655', 'rahul.desai@example.com', 'Finance', 'Accountant', '2018-07-01', 48000.00, '67 Baner Road, Pune', 'Active'),
(4, 'Priya', 'Kulkarni', 'F', '1995-11-14', '9012345678', 'priya.kulkarni@example.com', 'IT', 'Test Engineer', '2021-06-20', 45000.00, '89 Kothrud, Pune', 'Active'),
(5, 'Anil', 'Joshi', 'M', '1985-09-05', '9090909090', 'anil.joshi@example.com', 'Admin', 'Office Admin', '2017-11-25', 40000.00, '34 Shivajinagar, Pune', 'Active');
