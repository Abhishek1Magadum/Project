create database stagged_employee;
use stagged_employee;
CREATE TABLE Employee_Details (
    Employee_ID INT PRIMARY KEY,
    First_Name VARCHAR(50),
    Last_Name VARCHAR(50),
    Gender CHAR(1),
    Date_of_Birth DATE,
    Contact_Number VARCHAR(15),
    Email VARCHAR(100),
    Department VARCHAR(50),
    Designation VARCHAR(50),
    Date_of_Joining DATE,
    Salary DECIMAL(10,2),
    Address VARCHAR(255),
    Status VARCHAR(20)
);

